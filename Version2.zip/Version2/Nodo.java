/*
 * Universidad del Valle de Guatemala
 * Estructura de datos - Sección 10
 * Christopher García - 20541
 * HT10: Algoritmo de Floyd y grafos
 * Referencias obtenidas de https://devs4j.com/2017/11/24/implementa-un-grafo-de-ciudades-en-java/ 
 */

 //Imports
import java.util.ArrayList;
import java.util.List;

/*Clase Nodo útil para el grafo */
public class Nodo {

    //Atributos
    private String ciudad;
    private List<Arista> aristas;
 
    /**
     * Constructor de la clase
     * @param ciudad: Recibe el nombre de una ciudad
     */
    public Nodo(String ciudad) {
        this.ciudad = ciudad;
    }
 
    
    /** 
     * Método getCity
     * @return String: Retorna las ciudades
     */
    public String getCity() {
        return ciudad;
    }
 
    
    /** 
     * Método setCity: Establece una ciudad
     * @param ciudad: Recibe el nombre de una ciudad 
     */
    public void setCity(String ciudad) {
        this.ciudad = ciudad;
    }
 
    
    /** 
     * @return List<Arista>
     */
    public List<Arista> getEdges() {
        return aristas;
    }
 
    
    /** 
     * Método addEdge: Agrega aristas al grafo
     * @param edge: Recibe una arista
     */
    public void addEdge(Arista edge) {
        if (aristas == null) {
            aristas = new ArrayList<>();
        }
        aristas.add(edge);
    }
 
    
    /** 
     * Método toString
     * @return String
     */
    @Override
    public String toString() {
        return "\n \tNodo [Ciudad=" + ciudad + ", aristas=" + aristas + "]";
    }
}