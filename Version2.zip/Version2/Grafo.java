/*
 * Universidad del Valle de Guatemala
 * Estructura de datos - Sección 10
 * Christopher García - 20541
 * HT10: Algoritmo de Floyd y grafos
 * 
 * Referencias obtenidas de https://devs4j.com/2017/11/24/implementa-un-grafo-de-ciudades-en-java/
 */
import java.util.ArrayList;
import java.util.List;

public class Grafo {
 
    //Atributos
    private List<Nodo> nodos;
 
    /** 
     * Método addNode
     * @param nodo: Recibe un nodo que se agrega a la lista de nodos
     */
    public void addNode(Nodo nodo) {
        if (nodos == null) {
            nodos = new ArrayList<>();
        }
        nodos.add(nodo);
    }
 
    
    /** 
     * Método getNodos
     * @return List<Nodo>: Retorna la lista de nodos
     */
    public List<Nodo> getNodes() {
        return nodos;
    }

    
    /** 
     * Método isEmpty: Verifica si está vacío el grafo o no
     * @return boolean
     */
    public boolean isEmpty(){

        if(nodos == null){
            return true;
        } else {
           return false; 
        }
    }
    
    /** 
     * Método toString
     * @return String
     */
    @Override
    public String toString() {
        return "Grafo [nodos=" + nodos + "]";
    }
}
