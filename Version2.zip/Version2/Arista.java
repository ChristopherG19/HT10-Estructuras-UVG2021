/*
 * Universidad del Valle de Guatemala
 * Estructura de datos - Sección 10
 * Christopher García - 20541
 * HT10: Algoritmo de Floyd y grafos
 * Referencias obtenidas de https://devs4j.com/2017/11/24/implementa-un-grafo-de-ciudades-en-java/ 
 */

/*Clase Arista necesaria para crear el grafo*/
public class Arista {
    /*Atributos de la clase*/
    private Nodo origen;
    private Nodo destino;
    private double distancia;
 
    /** 
     * Constructor de la clase
     * @param origen: Recibe el nodo de la ciudad de origen
     * @param destino: Recibe el nodo de la ciudad de destino
     * @param distancia: Recibe la distancia entre ambas ciudades
     */
    public Arista(Nodo origen, Nodo destino, double distancia) {
        this.origen = origen;
        this.destino = destino;
        this.distancia = distancia;
    }
 
    
    /** 
     * Método getOrigin
     * @return Nodo: Retorna el nodo de origen
     */
    public Nodo getOrigin() {
        return origen;
    }
 
    
    /** 
     * Método setOrigin
     * @param origen: Se señala el nodo de origen
     */
    public void setOrigin(Nodo origen) {
        this.origen = origen;
    }
 
    
    /** 
     * Método getDestination
     * @return Nodo: Retorna el nodo de destino
     */
    public Nodo getDestination() {
        return destino;
    }
 
    
    /** 
     * Método setDestination
     * @param destino: Se señala el nodo de destino
     */
    public void setDestination(Nodo destino) {
        this.destino = destino;
    }
 
    
    /** 
     * Método getDistance
     * @return double: Se retorna la distancia entre dos ciudades
     */
    public double getDistance() {
        return distancia;
    }
 
    
    /** 
     * Método setDistance
     * @param distancia: Se establece la distancia entre dos ciudades
     */
    public void setDistance(double distancia) {
        this.distancia = distancia;
    }
 
    
    /** 
     * Método toString
     * @return String
     */
    @Override
    public String toString() {
        return "\n Aristas [Origen=" + origen.getCity() + ", destino=" + destino.getCity() + ", distancia="
                + distancia + "]";
    }
 
}