/*
 * Universidad del Valle de Guatemala
 * Estructura de datos - Sección 10
 * Christopher García - 20541
 * HT10: Algoritmo de Floyd y grafos
 * Referencias obtenidas de https://www.sanfoundry.com/java-program-implement-floyd-warshall-algorithm/
 */

/*
 * Clase FloyAlgorithm: Se encarga de manejar el algoritmo de Floyd
 */
public class FloydAlgorithm
{

    /*Atributos de la clase*/
    private int distancematrix[][];
    private int numberofvertices;
    public static final int INFINITY = 999;
 
    /** 
     * Constructor de la clase
     * @param numberofvertices: Número de vertices del grafo
     */
    public FloydAlgorithm(int numberofvertices)
    {
        distancematrix = new int[numberofvertices + 1][numberofvertices + 1];
        this.numberofvertices = numberofvertices;
    }
 
    
    /** 
     * Método floydwarshall: Retorna la matriz de adyacencia del grafo
     * @param adjacencymatrix[][]
     */
    public void floydwarshall(int adjacencymatrix[][])
    {
        for (int source = 1; source <= numberofvertices; source++)
        {
            for (int destination = 1; destination <= numberofvertices; destination++)
            {
                distancematrix[source][destination] = adjacencymatrix[source][destination];
            }
        }
 
        for (int intermediate = 1; intermediate <= numberofvertices; intermediate++)
        {
            for (int source = 1; source <= numberofvertices; source++)
            {
                for (int destination = 1; destination <= numberofvertices; destination++)
                {
                    if (distancematrix[source][intermediate] + distancematrix[intermediate][destination]
                         < distancematrix[source][destination])
                        distancematrix[source][destination] = distancematrix[source][intermediate] 
                            + distancematrix[intermediate][destination];
                }
            }
        }
 
        for (int source = 1; source <= numberofvertices; source++)
            System.out.print("\t" + source);
 
        System.out.println();
        for (int source = 1; source <= numberofvertices; source++)
        {
            System.out.print(source + "\t");
            for (int destination = 1; destination <= numberofvertices; destination++)
            {
                System.out.print(distancematrix[source][destination] + "\t");
            }
            System.out.println();
        }
    }

}